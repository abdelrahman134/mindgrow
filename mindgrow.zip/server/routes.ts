import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertContactSubmissionSchema,
  insertContentItemSchema,
  insertTeamMemberSchema,
  insertHeaderSettingsSchema,
  insertFooterSettingsSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ===== PUBLIC ROUTES =====
  
  // Contact form submission
  app.post('/api/contact', async (req, res) => {
    try {
      const validation = insertContactSubmissionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid data", errors: validation.error.errors });
      }

      const submission = await storage.createContactSubmission(validation.data);
      res.json({ message: "Thank you for your message! We will contact you soon.", id: submission.id });
    } catch (error) {
      console.error("Error creating contact submission:", error);
      res.status(500).json({ message: "Failed to submit message" });
    }
  });

  // ===== ADMIN ROUTES (Protected) =====
  
  // Contact submissions management
  app.get('/api/admin/contacts', isAuthenticated, async (req, res) => {
    try {
      const submissions = await storage.getAllContactSubmissions();
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching contact submissions:", error);
      res.status(500).json({ message: "Failed to fetch submissions" });
    }
  });

  app.get('/api/admin/contacts/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const submission = await storage.getContactSubmission(id);
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      res.json(submission);
    } catch (error) {
      console.error("Error fetching contact submission:", error);
      res.status(500).json({ message: "Failed to fetch submission" });
    }
  });

  app.patch('/api/admin/contacts/:id/read', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markContactAsRead(id);
      res.json({ message: "Marked as read" });
    } catch (error) {
      console.error("Error marking as read:", error);
      res.status(500).json({ message: "Failed to update" });
    }
  });

  app.patch('/api/admin/contacts/:id/reply', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { notes } = req.body;
      await storage.markContactAsReplied(id, notes);
      res.json({ message: "Marked as replied" });
    } catch (error) {
      console.error("Error marking as replied:", error);
      res.status(500).json({ message: "Failed to update" });
    }
  });

  app.delete('/api/admin/contacts/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteContactSubmission(id);
      res.json({ message: "Submission deleted" });
    } catch (error) {
      console.error("Error deleting submission:", error);
      res.status(500).json({ message: "Failed to delete" });
    }
  });

  // Content management
  app.get('/api/admin/content', async (req, res) => {
    try {
      const { page } = req.query;
      const items = page 
        ? await storage.getContentItemsByPage(page as string)
        : await storage.getAllContentItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching content items:", error);
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.post('/api/admin/content', isAuthenticated, async (req, res) => {
    try {
      const validation = insertContentItemSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid data", errors: validation.error.errors });
      }

      const item = await storage.createContentItem(validation.data);
      res.json(item);
    } catch (error) {
      console.error("Error creating content item:", error);
      res.status(500).json({ message: "Failed to create content" });
    }
  });

  app.patch('/api/admin/content/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid content ID" });
      }
      
      console.log(`Updating content ${id} with data:`, req.body);
      const item = await storage.updateContentItem(id, req.body);
      console.log('Content updated successfully:', item);
      res.json(item);
    } catch (error) {
      console.error("Error updating content item:", error);
      res.status(500).json({ 
        message: "Failed to update content",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.delete('/api/admin/content/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteContentItem(id);
      res.json({ message: "Content deleted" });
    } catch (error) {
      console.error("Error deleting content:", error);
      res.status(500).json({ message: "Failed to delete" });
    }
  });

  // Public team endpoint for website display
  app.get('/api/team', async (req, res) => {
    try {
      const members = await storage.getAllTeamMembers();
      res.json(members);
    } catch (error) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });

  // Team management
  app.get('/api/admin/team', isAuthenticated, async (req, res) => {
    try {
      const members = await storage.getAllTeamMembers();
      res.json(members);
    } catch (error) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });

  app.post('/api/admin/team', isAuthenticated, async (req, res) => {
    try {
      const validation = insertTeamMemberSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid data", errors: validation.error.errors });
      }

      const member = await storage.createTeamMember(validation.data);
      res.json(member);
    } catch (error) {
      console.error("Error creating team member:", error);
      res.status(500).json({ message: "Failed to create team member" });
    }
  });

  app.patch('/api/admin/team/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const member = await storage.updateTeamMember(id, req.body);
      res.json(member);
    } catch (error) {
      console.error("Error updating team member:", error);
      res.status(500).json({ message: "Failed to update team member" });
    }
  });

  app.delete('/api/admin/team/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTeamMember(id);
      res.json({ message: "Team member deleted" });
    } catch (error) {
      console.error("Error deleting team member:", error);
      res.status(500).json({ message: "Failed to delete" });
    }
  });

  // Header & Footer settings management
  app.get('/api/admin/header-settings', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.getHeaderSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching header settings:", error);
      res.status(500).json({ message: "Failed to fetch header settings" });
    }
  });

  app.patch('/api/admin/header-settings', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.updateHeaderSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating header settings:", error);
      res.status(500).json({ message: "Failed to update header settings" });
    }
  });

  app.get('/api/admin/footer-settings', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.getFooterSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching footer settings:", error);
      res.status(500).json({ message: "Failed to fetch footer settings" });
    }
  });

  app.patch('/api/admin/footer-settings', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.updateFooterSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating footer settings:", error);
      res.status(500).json({ message: "Failed to update footer settings" });
    }
  });

  // Button Links routes
  app.get('/api/admin/button-links', isAuthenticated, async (req, res) => {
    try {
      const links = await storage.getAllButtonLinks();
      res.json(links);
    } catch (error) {
      console.error("Error fetching button links:", error);
      res.status(500).json({ message: "Failed to fetch button links" });
    }
  });

  app.get('/api/admin/button-links/:contentKey', isAuthenticated, async (req, res) => {
    try {
      const link = await storage.getButtonLinkByContentKey(req.params.contentKey);
      res.json(link);
    } catch (error) {
      console.error("Error fetching button link:", error);
      res.status(500).json({ message: "Failed to fetch button link" });
    }
  });

  app.post('/api/admin/button-links', isAuthenticated, async (req, res) => {
    try {
      const newLink = await storage.createButtonLink(req.body);
      res.json(newLink);
    } catch (error) {
      console.error("Error creating button link:", error);
      res.status(500).json({ message: "Failed to create button link" });
    }
  });

  app.patch('/api/admin/button-links/:id', isAuthenticated, async (req, res) => {
    try {
      const updatedLink = await storage.updateButtonLink(parseInt(req.params.id), req.body);
      res.json(updatedLink);
    } catch (error) {
      console.error("Error updating button link:", error);
      res.status(500).json({ message: "Failed to update button link" });
    }
  });

  app.delete('/api/admin/button-links/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteButtonLink(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting button link:", error);
      res.status(500).json({ message: "Failed to delete button link" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
